/**
 * The AOP Alliance reflective interception abstraction.
 */
package org.aopalliance.intercept;
